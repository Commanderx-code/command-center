const invoke = window.__TAURI__?.core?.invoke;

const demoRepositories = [
  { name: "config-bible", path: "~/github/projects/config-bible", branch: "main", dirty: false, modified_files: 0, ahead: 0, behind: 0, remote_url: "https://github.com/commander/config-bible", last_commit: "Documented Home Manager workflow" },
  { name: "dotfiles", path: "~/dotfiles", branch: "main", dirty: true, modified_files: 3, ahead: 1, behind: 0, remote_url: "https://github.com/commander/dotfiles", last_commit: "Refine fish functions" },
  { name: "command-center", path: "~/github/projects/command-center", branch: "main", dirty: false, modified_files: 0, ahead: 0, behind: 0, remote_url: null, last_commit: "Start Command Center" },
  { name: "homelab", path: "~/github/projects/homelab", branch: "main", dirty: false, modified_files: 0, ahead: 0, behind: 2, remote_url: "https://github.com/commander/homelab", last_commit: "Update service inventory" }
];

const state = {
  repositories: [],
  roots: JSON.parse(localStorage.getItem("command-center.roots") || '["~/github/projects", "~/dotfiles"]'),
  activeView: "dashboard",
  desktop: Boolean(invoke)
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function escapeHtml(value = "") {
  return String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
}

function toast(message) {
  const element = $("#toast");
  element.textContent = message;
  element.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => element.classList.remove("show"), 2300);
}

function repoState(repo) {
  if (repo.dirty) return `${repo.modified_files} changed`;
  if (repo.ahead) return `↑ ${repo.ahead} ahead`;
  if (repo.behind) return `↓ ${repo.behind} behind`;
  return "✓ Clean";
}

function matchesFilter(repo, filter) {
  return filter === "all" || (filter === "dirty" && repo.dirty) || (filter === "clean" && !repo.dirty && !repo.ahead && !repo.behind) || (filter === "ahead" && repo.ahead) || (filter === "behind" && repo.behind);
}

function renderDashboardRepos() {
  const target = $("#dashboard-repos");
  const repos = state.repositories.slice(0, 4);
  if (!repos.length) {
    target.innerHTML = `<div class="empty-state"><div>No repositories found.<br><button class="secondary-button" data-open-settings>Add a scan folder</button></div></div>`;
    target.querySelector("[data-open-settings]")?.addEventListener("click", openSettings);
    return;
  }
  target.innerHTML = repos.map((repo) => `<div class="repo-row"><div class="repo-glyph">${escapeHtml(repo.name.slice(0, 2).toUpperCase())}</div><div class="repo-meta"><strong>${escapeHtml(repo.name)}</strong><small>${escapeHtml(repo.path)}</small></div><span class="branch">${escapeHtml(repo.branch || "detached")}</span><span class="repo-state ${repo.dirty ? "dirty" : ""}">${repoState(repo)}</span></div>`).join("");
}

function renderRepositoryGrid() {
  const search = $("#repo-search").value.trim().toLowerCase();
  const filter = $("#repo-filter").value;
  const repos = state.repositories.filter((repo) => `${repo.name} ${repo.path} ${repo.branch}`.toLowerCase().includes(search) && matchesFilter(repo, filter));
  const target = $("#repository-grid");
  if (!repos.length) {
    target.innerHTML = `<div class="empty-state panel">No repositories match this view.</div>`;
    return;
  }
  target.innerHTML = repos.map((repo) => `<article class="repo-card"><div class="repo-card-head"><div class="repo-glyph">${escapeHtml(repo.name.slice(0, 2).toUpperCase())}</div><span class="repo-state ${repo.dirty ? "dirty" : ""}">${repoState(repo)}</span></div><h3>${escapeHtml(repo.name)}</h3><div class="path">${escapeHtml(repo.path)}</div><div class="repo-card-details"><span class="detail-chip">⌘ ${escapeHtml(repo.branch || "detached")}</span><span class="detail-chip">${repo.last_commit ? escapeHtml(repo.last_commit) : "No commits"}</span></div><div class="repo-card-actions"><button data-open="editor" data-path="${escapeHtml(repo.path)}">Open</button><button data-open="terminal" data-path="${escapeHtml(repo.path)}">Terminal</button>${repo.remote_url ? `<button data-open="remote" data-path="${escapeHtml(repo.path)}">GitHub</button>` : ""}</div></article>`).join("");
  target.querySelectorAll("[data-open]").forEach((button) => button.addEventListener("click", () => openRepository(button.dataset.path, button.dataset.open)));
}

function updateStats() {
  const clean = state.repositories.filter((repo) => !repo.dirty && !repo.ahead && !repo.behind).length;
  $("#repo-total").textContent = state.repositories.length;
  $("#repo-count-nav").textContent = state.repositories.length;
  $("#repo-clean").textContent = `${clean} clean · ${state.repositories.length - clean} need attention`;
}

async function loadRepositories(showNotice = false) {
  $("#refresh-button").style.transform = "rotate(180deg)";
  try {
    state.repositories = state.desktop ? await invoke("discover_repositories", { roots: state.roots }) : demoRepositories;
    renderDashboardRepos();
    renderRepositoryGrid();
    updateStats();
    if (showNotice) toast(state.desktop ? `Scanned ${state.repositories.length} repositories` : "Preview refreshed — desktop scanning activates in Tauri");
  } catch (error) {
    toast(`Scan failed: ${error}`);
  } finally {
    setTimeout(() => $("#refresh-button").style.transform = "", 180);
  }
}

async function openRepository(path, target) {
  if (!state.desktop) return toast(`Preview: would open ${path} in ${target}`);
  try { await invoke("open_repository", { path, target }); }
  catch (error) { toast(`Could not open repository: ${error}`); }
}

const viewCopy = {
  dashboard: ["Overview", "Good evening, Commander."],
  repositories: ["Workspace", "Repositories"],
  sync: ["System", "System Sync"],
  backup: ["Recovery", "Backup & Restore"],
  config: ["Personalize", "Configuration"],
  health: ["Diagnostics", "System Health"]
};

const placeholderCopy = {
  sync: "Pull your declarative configuration, inspect drift, and apply Home Manager safely.",
  backup: "Run Restic backups, browse snapshots, verify repositories, and guide restores.",
  config: "Friendly editors for Ghostty, Fastfetch, Fish, Starship, Git, and Neovim.",
  health: "Disk, battery, package, service, backup, Git, and NVMe health in one view."
};

function switchView(view) {
  state.activeView = view;
  $$(".nav-item[data-view]").forEach((item) => item.classList.toggle("active", item.dataset.view === view));
  $$(".view").forEach((element) => element.classList.remove("active-view"));
  const directView = $(`#${view}-view`);
  (directView || $("#placeholder-view")).classList.add("active-view");
  $("#view-eyebrow").textContent = viewCopy[view]?.[0] || "Command Center";
  $("#view-title").textContent = viewCopy[view]?.[1] || "Command Center";
  if (!directView) {
    $("#placeholder-title").textContent = viewCopy[view]?.[1] || "Module coming next";
    $("#placeholder-copy").textContent = placeholderCopy[view] || "This module is planned for a future phase.";
  }
}

function renderRoots() {
  $("#roots-list").innerHTML = state.roots.map((root, index) => `<div class="root-row"><span>${escapeHtml(root)}</span><button type="button" data-remove-root="${index}" aria-label="Remove ${escapeHtml(root)}">×</button></div>`).join("");
  $$("[data-remove-root]").forEach((button) => button.addEventListener("click", () => {
    state.roots.splice(Number(button.dataset.removeRoot), 1);
    saveRoots();
    renderRoots();
  }));
}

function saveRoots() { localStorage.setItem("command-center.roots", JSON.stringify(state.roots)); }
function openSettings() { renderRoots(); $("#settings-dialog").showModal(); }

function bindEvents() {
  $$("[data-view]").forEach((button) => button.addEventListener("click", () => switchView(button.dataset.view)));
  $$("[data-go]").forEach((button) => button.addEventListener("click", () => switchView(button.dataset.go)));
  $("#settings-button").addEventListener("click", openSettings);
  $("#add-root-button").addEventListener("click", openSettings);
  $("#refresh-button").addEventListener("click", () => loadRepositories(true));
  $("#repo-search").addEventListener("input", renderRepositoryGrid);
  $("#repo-filter").addEventListener("change", renderRepositoryGrid);
  $("#quick-action-button").addEventListener("click", () => toast("Quick actions are available on the dashboard"));
  $$("[data-action]").forEach((button) => button.addEventListener("click", () => {
    const action = button.dataset.action;
    if (action === "sync") loadRepositories(true); else if (action === "config") switchView("config"); else toast(`${button.querySelector("strong").textContent} is planned for Phase 2`);
  }));
  $("#save-root-button").addEventListener("click", async () => {
    const input = $("#new-root-input");
    const root = input.value.trim();
    if (!root || state.roots.includes(root)) return;
    state.roots.push(root);
    input.value = "";
    saveRoots();
    renderRoots();
    await loadRepositories();
  });
}

bindEvents();
loadRepositories();
