use serde::Serialize;
use std::{
    collections::HashSet,
    env,
    path::{Path, PathBuf},
    process::Command,
};
use walkdir::WalkDir;

#[derive(Debug, Serialize)]
pub struct Repository {
    name: String,
    path: String,
    branch: String,
    dirty: bool,
    modified_files: usize,
    ahead: usize,
    behind: usize,
    remote_url: Option<String>,
    last_commit: Option<String>,
}

fn expand_home(path: &str) -> Result<PathBuf, String> {
    if path == "~" || path.starts_with("~/") {
        let home = env::var_os("HOME").ok_or("HOME is not set")?;
        return Ok(PathBuf::from(home).join(path.trim_start_matches("~/")));
    }
    Ok(PathBuf::from(path))
}

fn git(path: &Path, args: &[&str]) -> Option<String> {
    let output = Command::new("git").arg("-C").arg(path).args(args).output().ok()?;
    output.status.success().then(|| String::from_utf8_lossy(&output.stdout).trim().to_owned())
}

fn inspect(path: &Path) -> Repository {
    let status = git(path, &["status", "--porcelain"]).unwrap_or_default();
    let modified_files = status.lines().count();
    let branch = git(path, &["branch", "--show-current"]).unwrap_or_else(|| "detached".into());
    let remote_url = git(path, &["remote", "get-url", "origin"]).filter(|value| !value.is_empty());
    let last_commit = git(path, &["log", "-1", "--format=%s"]).filter(|value| !value.is_empty());
    let (ahead, behind) = git(path, &["rev-list", "--left-right", "--count", "HEAD...@{upstream}"])
        .and_then(|value| {
            let mut counts = value.split_whitespace().filter_map(|item| item.parse::<usize>().ok());
            Some((counts.next()?, counts.next()?))
        })
        .unwrap_or((0, 0));

    Repository {
        name: path.file_name().unwrap_or_default().to_string_lossy().into_owned(),
        path: path.to_string_lossy().into_owned(),
        branch,
        dirty: modified_files > 0,
        modified_files,
        ahead,
        behind,
        remote_url,
        last_commit,
    }
}

#[tauri::command]
pub fn discover_repositories(roots: Vec<String>) -> Result<Vec<Repository>, String> {
    let mut found = HashSet::new();
    for root in roots {
        let root = expand_home(&root)?;
        if !root.exists() { continue; }
        if root.join(".git").exists() { found.insert(root.clone()); }
        for entry in WalkDir::new(&root).min_depth(1).max_depth(3).follow_links(false).into_iter().filter_map(Result::ok) {
            if entry.file_type().is_dir() && entry.file_name() == ".git" {
                if let Some(parent) = entry.path().parent() { found.insert(parent.to_path_buf()); }
            }
        }
    }
    let mut repositories: Vec<_> = found.iter().map(|path| inspect(path)).collect();
    repositories.sort_by(|left, right| left.name.to_lowercase().cmp(&right.name.to_lowercase()));
    Ok(repositories)
}

fn remote_web_url(path: &Path) -> Result<String, String> {
    let remote = git(path, &["remote", "get-url", "origin"]).ok_or("Repository has no origin remote")?;
    let url = if let Some(value) = remote.strip_prefix("git@github.com:") {
        format!("https://github.com/{}", value.trim_end_matches(".git"))
    } else if let Some(value) = remote.strip_prefix("ssh://git@github.com/") {
        format!("https://github.com/{}", value.trim_end_matches(".git"))
    } else {
        remote.trim_end_matches(".git").to_owned()
    };
    Ok(url)
}

#[tauri::command]
pub fn open_repository(path: String, target: String) -> Result<(), String> {
    let path = expand_home(&path)?.canonicalize().map_err(|error| error.to_string())?;
    if !path.is_dir() || !path.join(".git").exists() { return Err("Path is not a Git repository".into()); }
    match target.as_str() {
        "editor" => Command::new("code").arg(&path).spawn().map(|_| ()).map_err(|error| format!("Could not launch editor: {error}")),
        "terminal" => Command::new("xdg-terminal-exec").arg("--working-directory").arg(&path).spawn().map(|_| ()).map_err(|error| format!("Could not launch terminal: {error}")),
        "remote" => open::that(remote_web_url(&path)?).map_err(|error| format!("Could not open remote: {error}")),
        _ => Err("Unsupported launch target".into()),
    }
}
